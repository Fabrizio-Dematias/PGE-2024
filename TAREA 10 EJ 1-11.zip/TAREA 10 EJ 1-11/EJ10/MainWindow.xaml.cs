﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace UnitConverter
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Convert_Click(object sender, RoutedEventArgs e)
        {
            // Validacion de entrada
            if (!double.TryParse(txtValue.Text, out double value))
            {
                MessageBox.Show("Por favor ingrese un valor válido.");
                return;
            }

            string fromUnit = (cbFromUnit.SelectedItem as ComboBoxItem).Content.ToString();
            string toUnit = (cbToUnit.SelectedItem as ComboBoxItem).Content.ToString();

            // Validación de conversión entre categorías
            if (!AreUnitsCompatible(fromUnit, toUnit))
            {
                MessageBox.Show("No se pueden convertir unidades de diferentes categorías. Por favor, seleccione unidades compatibles.");
                return;
            }

            // Realizar la conversion
            double result = ConvertUnits(value, fromUnit, toUnit);

            // Mostrar el resultado
            lblResult.Text = $"{value} {fromUnit} = {result} {toUnit}";
        }

        private bool AreUnitsCompatible(string fromUnit, string toUnit)
        {
            string[] lengthUnits = { "Metros", "Kilómetros" };
            string[] weightUnits = { "Gramos", "Kilogramos" };

            if ((lengthUnits.Contains(fromUnit) && lengthUnits.Contains(toUnit)) ||
                (weightUnits.Contains(fromUnit) && weightUnits.Contains(toUnit)))
            {
                return true;
            }

            return false;
        }

        private double ConvertUnits(double value, string fromUnit, string toUnit)
        {

            double baseValue = value; // Valor convertido a la unidad base (metros o gramos)

            // Convertir la unidad de origen a la unidad base
            switch (fromUnit)
            {
                case "Metros":
                    baseValue = value;
                    break;
                case "Kilómetros":
                    baseValue = value * 1000;
                    break;
                case "Gramos":
                    baseValue = value;
                    break;
                case "Kilogramos":
                    baseValue = value * 1000;
                    break;
            }

            double finalValue = baseValue;
            switch (toUnit)
            {
                case "Metros":
                    finalValue = baseValue;
                    break;
                case "Kilómetros":
                    finalValue = baseValue / 1000;
                    break;
                case "Gramos":
                    finalValue = baseValue;
                    break;
                case "Kilogramos":
                    finalValue = baseValue / 1000;
                    break;
            }

            return finalValue;
        }
    }
}
