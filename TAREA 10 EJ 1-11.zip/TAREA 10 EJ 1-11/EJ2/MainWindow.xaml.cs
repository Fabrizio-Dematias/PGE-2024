﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WpfDrawingApp
{
    public partial class MainWindow : Window
    {
        private Polyline currentLine;  
        private bool isDrawing = false; 

        public MainWindow()
        {
            InitializeComponent();
        }

       
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            isDrawing = true;

           
            currentLine = new Polyline
            {
                Stroke = new SolidColorBrush(GetSelectedColor()),
                StrokeThickness = lineThicknessSlider.Value
            };
            currentLine.Points.Add(e.GetPosition(drawingCanvas));

            
            drawingCanvas.Children.Add(currentLine);
        }

        
        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing && currentLine != null)
            {
                currentLine.Points.Add(e.GetPosition(drawingCanvas));
            }
        }

        
        private void Canvas_MouseUp(object sender, MouseButtonEventArgs e)
        {
            isDrawing = false;
            currentLine = null;
        }

        
        private Color GetSelectedColor()
        {
            string selectedColor = ((ComboBoxItem)colorPicker.SelectedItem).Content.ToString();
            return (Color)ColorConverter.ConvertFromString(selectedColor);
        }

        
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            drawingCanvas.Children.Clear(); 
        }
    }
}
