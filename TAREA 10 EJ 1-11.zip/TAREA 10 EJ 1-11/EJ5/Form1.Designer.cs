﻿namespace EJ5_Tarea10
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnCargarImagen = new System.Windows.Forms.Button();
            this.pbImagen = new System.Windows.Forms.PictureBox();
            this.trackBarTamano = new System.Windows.Forms.TrackBar();
            this.trackBarBrillo = new System.Windows.Forms.TrackBar();
            this.btnAplicarCambios = new System.Windows.Forms.Button();
            this.btnGuardarImagen = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarTamano)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBrillo)).BeginInit();
            this.SuspendLayout();

            // 
            // btnCargarImagen
            // 
            this.btnCargarImagen.Location = new System.Drawing.Point(12, 12);
            this.btnCargarImagen.Name = "btnCargarImagen";
            this.btnCargarImagen.Size = new System.Drawing.Size(120, 40);
            this.btnCargarImagen.TabIndex = 0;
            this.btnCargarImagen.Text = "Cargar Imagen";
            this.btnCargarImagen.UseVisualStyleBackColor = true;
            this.btnCargarImagen.Click += new System.EventHandler(this.btnCargarImagen_Click);

            // 
            // pbImagen
            // 
            this.pbImagen.Location = new System.Drawing.Point(12, 70);
            this.pbImagen.Name = "pbImagen";
            this.pbImagen.Size = new System.Drawing.Size(460, 320);
            this.pbImagen.TabIndex = 1;
            this.pbImagen.TabStop = false;
            this.pbImagen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;

            // 
            // trackBarTamano
            // 
            this.trackBarTamano.Location = new System.Drawing.Point(12, 410);
            this.trackBarTamano.Maximum = 100;
            this.trackBarTamano.Minimum = 10;
            this.trackBarTamano.Name = "trackBarTamano";
            this.trackBarTamano.Size = new System.Drawing.Size(460, 45);
            this.trackBarTamano.TabIndex = 2;
            this.trackBarTamano.Value = 100;

            // 
            // trackBarBrillo
            // 
            this.trackBarBrillo.Location = new System.Drawing.Point(12, 470);
            this.trackBarBrillo.Maximum = 100;
            this.trackBarBrillo.Minimum = -100;
            this.trackBarBrillo.Name = "trackBarBrillo";
            this.trackBarBrillo.Size = new System.Drawing.Size(460, 45);
            this.trackBarBrillo.TabIndex = 3;
            this.trackBarBrillo.Value = 0;

            // 
            // btnAplicarCambios
            // 
            this.btnAplicarCambios.Location = new System.Drawing.Point(12, 530);
            this.btnAplicarCambios.Name = "btnAplicarCambios";
            this.btnAplicarCambios.Size = new System.Drawing.Size(120, 40);
            this.btnAplicarCambios.TabIndex = 4;
            this.btnAplicarCambios.Text = "Aplicar Cambios";
            this.btnAplicarCambios.UseVisualStyleBackColor = true;
            this.btnAplicarCambios.Click += new System.EventHandler(this.btnAplicarCambios_Click);

            // 
            // btnGuardarImagen
            // 
            this.btnGuardarImagen.Location = new System.Drawing.Point(150, 530);
            this.btnGuardarImagen.Name = "btnGuardarImagen";
            this.btnGuardarImagen.Size = new System.Drawing.Size(120, 40);
            this.btnGuardarImagen.TabIndex = 5;
            this.btnGuardarImagen.Text = "Guardar Imagen";
            this.btnGuardarImagen.UseVisualStyleBackColor = true;
            this.btnGuardarImagen.Click += new System.EventHandler(this.btnGuardarImagen_Click);

            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 591);
            this.Controls.Add(this.btnGuardarImagen);
            this.Controls.Add(this.btnAplicarCambios);
            this.Controls.Add(this.trackBarBrillo);
            this.Controls.Add(this.trackBarTamano);
            this.Controls.Add(this.pbImagen);
            this.Controls.Add(this.btnCargarImagen);
            this.Name = "Form1";
            this.Text = "Editor de Imágenes";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbImagen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarTamano)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBrillo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnCargarImagen;
        private System.Windows.Forms.PictureBox pbImagen;
        private System.Windows.Forms.TrackBar trackBarTamano;
        private System.Windows.Forms.TrackBar trackBarBrillo;
        private System.Windows.Forms.Button btnAplicarCambios;
        private System.Windows.Forms.Button btnGuardarImagen;
    }
}
