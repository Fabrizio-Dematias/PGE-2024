﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace EJ5_Tarea10
{
    public partial class Form1 : Form
    {
        private Image imagenOriginal;
        private Image imagenEditada;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Inicializa los valores si es necesario.
        }

        private void btnCargarImagen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Archivos de Imagen|*.jpg;*.jpeg;*.png;*.bmp"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                imagenOriginal = Image.FromFile(openFileDialog.FileName);
                pbImagen.Image = imagenOriginal;
                imagenEditada = (Image)imagenOriginal.Clone();
            }
        }

        private void btnAplicarCambios_Click(object sender, EventArgs e)
        {
            if (imagenOriginal == null) return;

            // Aplicar el ajuste de tamaño
            int nuevoAncho = imagenOriginal.Width * trackBarTamano.Value / 100;
            int nuevoAlto = imagenOriginal.Height * trackBarTamano.Value / 100;

            Bitmap imagenRedimensionada = new Bitmap(imagenOriginal, nuevoAncho, nuevoAlto);

            // Ajustar brillo (esto es un ejemplo básico)
            float factorBrillo = 1.0f + trackBarBrillo.Value / 100.0f;
            Bitmap imagenBrilloAjustado = AjustarBrillo(imagenRedimensionada, factorBrillo);

            pbImagen.Image = imagenBrilloAjustado;
            imagenEditada = imagenBrilloAjustado;
        }

        private Bitmap AjustarBrillo(Bitmap image, float brillo)
        {
            Bitmap temp = new Bitmap(image.Width, image.Height);
            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color c = image.GetPixel(x, y);
                    int r = (int)(c.R * brillo);
                    int g = (int)(c.G * brillo);
                    int b = (int)(c.B * brillo);
                    r = Math.Min(255, Math.Max(0, r));
                    g = Math.Min(255, Math.Max(0, g));
                    b = Math.Min(255, Math.Max(0, b));
                    temp.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }
            return temp;
        }

        private void btnGuardarImagen_Click(object sender, EventArgs e)
        {
            if (imagenEditada == null) return;

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Archivos de Imagen|*.jpg;*.jpeg;*.png;*.bmp"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                imagenEditada.Save(saveFileDialog.FileName);
            }
        }
    }
}
