﻿using System;
using System.Windows;

namespace TipCalculator
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            sldPorcentaje.ValueChanged += SldPorcentaje_ValueChanged;
        }

        private void SldPorcentaje_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lblPorcentaje.Content = $"{sldPorcentaje.Value}%";
        }

        private void btnCalcular_Click(object sender, RoutedEventArgs e)
        {
            // Validar que el monto ingresado sea válido
            if (double.TryParse(txtMontoTotal.Text, out double montoTotal))
            {
                double porcentajePropina = sldPorcentaje.Value;
                double propina = montoTotal * (porcentajePropina / 100);
                double totalConPropina = montoTotal + propina;

                // Mostrar resultados
                lblResultado.Text = $"Propina: ${propina:F2}";
                lblTotalConPropina.Text = $"Total con propina: ${totalConPropina:F2}";
            }
            else
            {
                MessageBox.Show("Por favor, ingrese un monto válido.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
