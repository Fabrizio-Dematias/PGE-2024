using System;
using System.Windows.Forms;

namespace RegistroGastos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            cbMoneda.Items.Clear();

            // Agregar opciones de moneda (USD y EUR) solo una vez
            cbMoneda.Items.Add("USD");
            cbMoneda.Items.Add("EUR");
            cbMoneda.SelectedIndex = 0;
        }

        private double ConvertirMoneda(double valorMonedaLocal, string moneda)
        {
            double tasaConversion = 1.0;

            if (moneda == "USD")
            {
                tasaConversion = 0.85; // Ejemplo: 1 peso argentino = 0.85 USD
            }
            else if (moneda == "EUR")
            {
                tasaConversion = 0.80;
            }

            return valorMonedaLocal * tasaConversion;
        }

        //agregar gasto en moneda local
        private void btnAgregarGasto_Click(object sender, EventArgs e)
        {
            try
            {
                string descripcion = txtDescripcion.Text;
                double valorMonedaLocal = double.Parse(txtValor.Text);

                if (string.IsNullOrEmpty(descripcion))
                {
                    MessageBox.Show("Debe ingresar una descripci�n.");
                    return;
                }

                dataGridGastos.Rows.Add(descripcion, valorMonedaLocal.ToString("F2"));

                txtDescripcion.Clear();
                txtValor.Clear();
            }
            catch (FormatException)
            {
                MessageBox.Show("Ingrese un valor num�rico v�lido para el gasto.");
            }
        }

        private void btnConvertir_Click(object sender, EventArgs e)
        {
            double totalMonedaLocal = 0;

            // Sumar todos los gastos registrados en moneda local
            foreach (DataGridViewRow row in dataGridGastos.Rows)
            {
                if (row.Cells[1].Value != null)
                {
                    totalMonedaLocal += Convert.ToDouble(row.Cells[1].Value);
                }
            }

            string monedaSeleccionada = cbMoneda.SelectedItem.ToString();

            // Convertir el total a la moneda seleccionada (USD o EUR)
            double totalConvertido = ConvertirMoneda(totalMonedaLocal, monedaSeleccionada);

            lblTotalConvertido.Text = $"Total en {monedaSeleccionada}: {totalConvertido:C2}";
        }
    }
}
