﻿using System;

public class DatosVentas
{
    public Dictionary<string, double> VentasPorMes { get; set; }

    public DatosVentas()
    {
        VentasPorMes = new Dictionary<string, double>()
        {
            { "Enero", 5000 },
            { "Febrero", 3000 },
            { "Marzo", 4500 },
            { "Abril", 6000 },
            { "Mayo", 7000 },
            { "Junio", 5500 },
            { "Julio", 6500 },
            { "Agosto", 4000 },
            { "Septiembre", 7200 },
            { "Octubre", 8500 },
            { "Noviembre", 9000 },
            { "Diciembre", 10000 }
        };
    }
}
