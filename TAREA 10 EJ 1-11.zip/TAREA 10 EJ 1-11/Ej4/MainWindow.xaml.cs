﻿using LiveCharts;
using LiveCharts.Wpf;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ej4
{
    public partial class MainWindow : Window
    {
        private DatosVentas datosVentas;  // Clase que contiene las ventas por mes

        public SeriesCollection SeriesCollection { get; set; }
        public List<string> Labels { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            datosVentas = new DatosVentas();

            // Inicializar gráfico
            CargarMeses();
            GenerarGrafico(datosVentas.VentasPorMes.Keys.ToList());

            DataContext = this;  // Configurar el DataContext para el binding de Labels
        }

        // Cargar los meses en el ListBox
        private void CargarMeses()
        {
            MesesListBox.ItemsSource = datosVentas.VentasPorMes.Keys;
        }

        // Generar el gráfico de ventas para los meses seleccionados
        private void GenerarGrafico(List<string> meses)
        {
            // Filtrar los meses seleccionados y extraer los datos correspondientes
            var ventasSeleccionadas = datosVentas.VentasPorMes
                .Where(venta => meses.Contains(venta.Key))
                .ToDictionary(venta => venta.Key, venta => venta.Value);

            // Crear la serie de columnas para las ventas
            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = "Ventas",
                    Values = new ChartValues<double>(ventasSeleccionadas.Values)
                }
            };

            // Actualizar etiquetas de los ejes (meses)
            Labels = ventasSeleccionadas.Keys.ToList();

            // Asignar los datos actualizados al gráfico
            VentasChart.Series = SeriesCollection;
            VentasChart.Update(true, true);  // Forzar la actualización del gráfico
        }

        // Manejar el cambio de selección en el ListBox
        private void MesesListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Obtener los meses seleccionados
            var mesesSeleccionados = MesesListBox.SelectedItems.Cast<string>().ToList();

            // Si no hay selección, mostrar todos los meses
            if (!mesesSeleccionados.Any())
            {
                mesesSeleccionados = datosVentas.VentasPorMes.Keys.ToList();
            }

            // Actualizar el gráfico con los meses seleccionados
            GenerarGrafico(mesesSeleccionados);
        }
    }
}