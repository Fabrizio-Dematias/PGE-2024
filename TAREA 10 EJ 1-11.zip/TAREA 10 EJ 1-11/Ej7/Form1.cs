﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ej7
{
    public partial class GuessingGameForm : Form
    {
        private int randomNumber;
        private Random random;

        public GuessingGameForm()
        {
            InitializeComponent();
            random = new Random();
            StartNewGame();
        }

        private void StartNewGame()
        {
            randomNumber = random.Next(1, 101);
            lblMessage.Text = "Adivina el número entre 1 y 100";
            txtGuess.Text = "";
            btnGuess.Enabled = true;
        }


        private void btnGuess_Click_1(object sender, EventArgs e)
        {
            int userGuess;

            if (int.TryParse(txtGuess.Text, out userGuess))
            {
                if (userGuess < randomNumber)
                {
                    lblMessage.Text = "El número es mayor";
                }
                else if (userGuess > randomNumber)
                {
                    lblMessage.Text = "El número es menor";
                }
                else
                {
                    lblMessage.Text = "¡Felicidades! Adivinaste el número.";
                    btnGuess.Enabled = false;
                }
            }
            else
            {
                lblMessage.Text = "Por favor, ingresa un número válido.";
            }
        }

        private void btnRestart_Click_1(object sender, EventArgs e)
        {
            StartNewGame();
        }
    }
}
